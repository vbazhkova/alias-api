const API_URL = 'https://d5d4l8gbut1huec75f8q.apigw.yandexcloud.net';

document.addEventListener('DOMContentLoaded', function() {
    console.log('Адрес страницы был изменен');

    const urlParams = new URLSearchParams(window.location.search);
    const body = JSON.parse(urlParams.get('body'));
    const game_id = body['game_id']
    const next_round = body['next_round']
    const team_id = body['next_team']['team_id']

    console.log(body)

    const teamLabel = document.querySelector(`.e407_367`)
    teamLabel.innerHTML = `Начинает команда - ${body['next_team']['team_name']}`

    const button = document.querySelector(`.e407_365`)

    if (button) {
        button.addEventListener('click', function() {
            console.log('press button')
            
            const body = JSON.stringify({
                team_id: team_id,
                round_id: next_round
            })
            console.log(body)
            fetch(`${API_URL}/game/next/round?game_id=${game_id}`, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Access-Control-Allow-Origin': '*',
                  'Access-Control-Allow-Methods': '*'
                },
                body: body
              })
              .then(response => response.json())
              .then(data => {
                console.log(data);
                if (data) {
                    console.log('success request game/next/round');
                    window.location.href = `card.html?body=${JSON.stringify(data)}`;
                } else {
                  console.log('error request game/next/round');
                }
              })
              .catch(error => console.error(error));
        });
    }
});