const API_URL = 'https://d5d4l8gbut1huec75f8q.apigw.yandexcloud.net';

document.addEventListener('DOMContentLoaded', function() {
    console.log('Адрес страницы был изменен');

    const urlParams = new URLSearchParams(window.location.search);
    const body = JSON.parse(urlParams.get('body'));
    const game_id = body['game_id']
    const team_id = body['first_team']['team_id']

    console.log(body)

    const teamLabel = document.querySelector(`.e407_364`)
    teamLabel.innerHTML = `Начинает команда - ${body['first_team']['team_name']}`

    const button = document.querySelector(`.e407_361`)

    if (button) {
        console.log('have button')
        button.addEventListener('click', function() {
            console.log('press button')
            fetch(`${API_URL}/game/start?game_id=${game_id}`, {
                method: 'PATCH',
                headers: {
                  'Content-Type': 'application/json',
                  'Access-Control-Allow-Origin': '*',
                  'Access-Control-Allow-Methods': '*'
                },
                body: JSON.stringify({
                  team_id: team_id
                })
              })
              .then(response => response.json())
              .then(data => {
                console.log(data);
                if (data) {
                  console.log('success request /game/start');
                  window.location.href = `card.html?body=${JSON.stringify(data)}`;
                } else {
                  console.log('error request /game/start');
                }
              })
              .catch(error => console.error(error));
        });
    }
});