const API_URL = 'https://d5d4l8gbut1huec75f8q.apigw.yandexcloud.net';

document.addEventListener('DOMContentLoaded', function() {
    const randomTheme = document.getElementsByClassName('e407_212')[0];
    const actionsTheme = document.getElementsByClassName('e407_218')[0];
    const wordsTheme = document.getElementsByClassName('e407_220')[0];
    const foodTheme = document.getElementsByClassName('e407_222')[0];
    randomTheme.classList.add('unselected_theme');
    actionsTheme.classList.add('unselected_theme');
    wordsTheme.classList.add('unselected_theme');
    foodTheme.classList.add('unselected_theme');

    const score25 = document.getElementsByClassName('e407_229')[0];
    const score50 = document.getElementsByClassName('e407_230')[0];
    const score75 = document.getElementsByClassName('e407_231')[0];
    score25.classList.add('unselected_points');
    score50.classList.add('unselected_points');
    score75.classList.add('unselected_points');

    const roundTime30 = document.getElementsByClassName('e407_241')[0];
    const roundTime60 = document.getElementsByClassName('e407_242')[0];
    const roundTime90 = document.getElementsByClassName('e407_243')[0];
    roundTime30.classList.add('unselected_round');
    roundTime60.classList.add('unselected_round');
    roundTime90.classList.add('unselected_round');

    const team2 = document.getElementsByClassName('e407_263')[0];
    const team3 = document.getElementsByClassName('e407_268')[0];
    const team4 = document.getElementsByClassName('e407_270')[0];
    const team5 = document.getElementsByClassName('e407_272')[0];
    const team6 = document.getElementsByClassName('e407_274')[0];
    const team7 = document.getElementsByClassName('e407_276')[0];
    team2.classList.add('unselected_team');
    team3.classList.add('unselected_team');
    team4.classList.add('unselected_team');
    team5.classList.add('unselected_team');
    team6.classList.add('unselected_team');
    team7.classList.add('unselected_team');

    const button = document.querySelector(`.e407_280`)

    if (button) {
        button.addEventListener('click', function() {
            const activeTheme = document.body.querySelector(`.selected_theme`);
            const activeRound = document.body.querySelector(`.selected_round`);
            const activePoints = document.body.querySelector(`.selected_points`);
            const activeTeam = document.body.querySelector(`.selected_team`);

            const body = JSON.stringify({
                topic_id: parseInt(activeTheme.dataset.networkId),
                points_to_win: parseInt(activePoints.innerText),
                round_time: parseInt(activeRound.innerText),
                teams_count: parseInt(activeTeam.innerText)
            })
            fetch(`${API_URL}/game/configure`, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Access-Control-Allow-Origin': '*',
                  'Access-Control-Allow-Methods': '*'
                },
                body: body
              })
              .then(response => response.json())
              .then(data => {
                console.log(data);
                if (data) {
                  console.log('success request /game/configure');
                  window.location.href = `ready.html?body=${JSON.stringify(data)}`;
                } else {
                  console.log('error request /game/configure');
                }
              })
              .catch(error => console.error(error));
        });
    }
});

const handleThemeClick = (event) => {
    const activeTab = document.body.querySelector(`.selected_theme`);
    const currentTab = event.currentTarget;

    if (activeTab) {
        if (activeTab === currentTab) {
            currentTab.classList.remove('selected_theme');
            currentTab.classList.add('unselected_theme');
        } else {
            activeTab.classList.remove('selected_theme');
            activeTab.classList.add('unselected_theme');
            currentTab.classList.remove('unselected_theme');
            currentTab.classList.add('selected_theme');
        }
    } else {
        currentTab.classList.remove('unselected_theme');
        currentTab.classList.add('selected_theme');
    }
  };

const handlePointsClick = (event) => {
    const activeTab = document.body.querySelector(`.selected_points`);
    const currentTab = event.currentTarget;

    if (activeTab) {
        if (activeTab === currentTab) {
            currentTab.classList.remove('selected_points');
            currentTab.classList.add('unselected_points');
        } else {
            activeTab.classList.remove('selected_points');
            activeTab.classList.add('unselected_points');
            currentTab.classList.remove('unselected_points');
            currentTab.classList.add('selected_points');
        }
    } else {
        currentTab.classList.remove('unselected_points');
        currentTab.classList.add('selected_points');
    }
  };

const handleRoundClick = (event) => {
    const activeTab = document.body.querySelector(`.selected_round`);
    const currentTab = event.currentTarget;

    if (activeTab) {
        if (activeTab === currentTab) {
            currentTab.classList.remove('selected_round');
            currentTab.classList.add('unselected_round');
        } else {
            activeTab.classList.remove('selected_round');
            activeTab.classList.add('unselected_round');
            currentTab.classList.remove('unselected_round');
            currentTab.classList.add('selected_round');
        }
    } else {
        currentTab.classList.remove('unselected_round');
        currentTab.classList.add('selected_round');
    }
  };

const handleTeamClick = (event) => {
    const activeTab = document.body.querySelector(`.selected_team`);
    const currentTab = event.currentTarget;

    if (activeTab) {
        if (activeTab === currentTab) {
            currentTab.classList.remove('selected_team');
            currentTab.classList.add('unselected_team');
        } else {
            activeTab.classList.remove('selected_team');
            activeTab.classList.add('unselected_team');
            currentTab.classList.remove('unselected_team');
            currentTab.classList.add('selected_team');
        }
    } else {
        currentTab.classList.remove('unselected_team');
        currentTab.classList.add('selected_team');
    }
  };