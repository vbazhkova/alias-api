const API_URL = 'https://d5d4l8gbut1huec75f8q.apigw.yandexcloud.net';

let game_id = 0

document.addEventListener('DOMContentLoaded', function() {
    console.log('Адрес страницы был изменен');

    const urlParams = new URLSearchParams(window.location.search);
    const body = JSON.parse(urlParams.get('body'));
    const winner_name = body['winner_name']
    const points = body['stats']['points']
    const times = body['stats']['times']
    game_id = body['game_id']

    console.log(body)
    console.log(points)

    const teamLabel = document.querySelector(`.e407_372`)
    teamLabel.innerHTML = `Победили “${winner_name}”🎉`

    var index = 1
    for (let point of points) {
        if (index % 2 === 0) {
            createRightTopDiv(point)
        } else {
            createLeftTopDiv(point)
        }
        index += 1
        console.log(point)
    }

    index = 0
    for (let time of times) {
        if (index % 2 === 0) {
            createLeftBottomDiv(time)
        } else {
            createRightBottomDiv(time)
        }
        index += 1
        console.log(time)
    }
});

function createLeftTopDiv(point) {
    var container_left_top = document.querySelector(`.column_left_points`);
    var divs = createTopDiv(point);
    container_left_top.appendChild(divs[0]);
    divs[0].appendChild(divs[1])
}

function createRightTopDiv(point) {
    var container_right_top = document.querySelector(`.column_right_points`);
    var divs = createTopDiv(point);
    container_right_top.appendChild(divs[0]);
    divs[0].appendChild(divs[1])
}

function createTopDiv(point) {
    var cellDiv = document.createElement("div");
    cellDiv.className = "cell"
    var textDiv = document.createElement("div")
    textDiv.className = "text"
    textDiv.innerText = `${point['team_name']} — ${point['points']}`
    return [cellDiv, textDiv]
}

function createLeftBottomDiv(time) {
    var container_left_top = document.querySelector(`.column_left_times`);
    var divs = createBottomDiv(time);
    container_left_top.appendChild(divs[0]);
    divs[0].appendChild(divs[1])
}

function createRightBottomDiv(time) {
    var container_right_top = document.querySelector(`.column_right_times`);
    var divs = createBottomDiv(time);
    container_right_top.appendChild(divs[0]);
    divs[0].appendChild(divs[1])
}

function createBottomDiv(time) {
    var cellDiv = document.createElement("div");
    cellDiv.className = "cell"
    var textDiv = document.createElement("div")
    textDiv.className = "text"
    textDiv.innerText = `${time['team_name']} — ${time['times']}`
    return [cellDiv, textDiv]
}

const handleNewGameClick = (event) => {
    window.location.href = `index.html`;
};

const handleRepeatGameClick = (event) => {
    fetch(`${API_URL}/game?game_id=${game_id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': '*'
        }
      })
      .then(response => response.json())
      .then(data => {
        console.log(data);
            if (data) {
              console.log('success request /game');
              window.location.href = `ready.html?body=${JSON.stringify(data)}`;
            } else {
              console.log('error request /game');
            }
      })
      .catch(error => console.error(error));
};