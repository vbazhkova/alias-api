const API_URL = 'https://d5d4l8gbut1huec75f8q.apigw.yandexcloud.net';

let game_id = 0
let team_id = 0
let round_id = 0
let card_id = 0
let round_time = 0
let is_time_up = false

document.addEventListener('DOMContentLoaded', function() {
    console.log('Страница карточки открыта');

    const urlParams = new URLSearchParams(window.location.search);
    const body = JSON.parse(urlParams.get('body'));
    const question = body['question']
    game_id = parseInt(body['game_id'])
    team_id = parseInt(body['team_id'])
    round_time = parseInt(body['round_time'])
    round_id = parseInt(question['round_id'])
    card_id = parseInt(question['question']['card_id'])

    const cardLabel = document.querySelector(`.e407_339`)
    cardLabel.innerHTML = question['question']['question']

    timer()
});

const handleSkipClick = (event) => {
    const body = JSON.stringify({
        is_answered: false,
        card_id: card_id,
        round_id: round_id
    })
    fetchNext(body)
}

const handleAnswerClick = (event) => {
    const body = JSON.stringify({
        is_answered: true,
        card_id: card_id,
        round_id: round_id
    })
    fetchNext(body)
}

function fetchNext(body) {
    console.log(body)
    fetch(`${API_URL}/game/answer?game_id=${game_id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': '*'
        },
        body: body
      })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        if (data) {
            console.log('success request /game/answer');
            if (data['winner_name']) {
                console.log(data['winner_name'])
                window.location.href = `stats.html?body=${JSON.stringify(data)}`;
                return
            }
            if (is_time_up == true) {
                nextScreen()
            } else {
                const next_card = data['next_card']
                card_id = next_card['card_id']
                next_question = next_card['question']
                const cardLabel = document.querySelector(`.e407_339`)
                cardLabel.innerHTML = next_question
            }
        } else {
          console.log('error request /game/answer');
        }
      })
      .catch(error => console.error(error));
}

function timer() {
    timeInSeconds = round_time
    var x = setInterval(function() {
        var minutes = Math.floor(timeInSeconds / 60);
        var seconds = timeInSeconds % 60;
      
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
      
        document.querySelector(`.e407_348`).innerHTML = 'Осталось: ' + minutes + ":" + seconds;
      
        timeInSeconds--;
      
        if (timeInSeconds < 0) {
          clearInterval(x);
          document.querySelector(`.e407_348`).innerHTML = 'Осталось: 00:00';
          is_time_up = true
        }
      }, 1000);
}

function nextScreen() {
    const body = JSON.stringify({
        team_id: team_id,
        round_id: round_id
    })
    console.log(body)
    fetch(`${API_URL}/game/round?game_id=${game_id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': '*'
        },
        body: body
      })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        if (data) {
            console.log('success request /game/round');
            window.location.href = `next_ready.html?body=${JSON.stringify(data)}`;
        } else {
          console.log('error request /game/round');
        }
      })
      .catch(error => console.error(error));
}